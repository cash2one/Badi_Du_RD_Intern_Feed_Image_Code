#!/bin/bash

HADOOP_HOME="/home/users/zhuoan/tools/hadoop-client/nmg01/hadoop"

#@mainfest means done
INPUT_PATH="hdfs://szwg-stoff-hdfs.dmop.baidu.com:54310/app/dt/minos/200036716/pblog/ps/ubm_mergelog_access/1541/20160224/*/*.log"
#INPUT_PATH="hdfs://szwg-stoff-hdfs.dmop.baidu.com:54310/app/dt/minos/200036716/pblog/ubm_wise_mergelog_access/ubm_wise_mergelog_access/1537/20160105/*/*.log"

recommend_path=hdfs://nmg01-global-hdfs.dmop.baidu.com:54310/user/kga-rec/recommend
output=$recommend_path/temp/xx

JOB_NAME="pc-mergelog-stream-sample"
sample_id=19033
src_id=21180
split_size=1024*1024*1024
# clear output environment
$HADOOP_HOME/bin/hadoop fs -rmr $output

#-D mapred.job.queue.name=kga-ml \
#-reducer "Python/Jumbo/bin/python.sh pc_mergelog_stream.py run_reduce" \
$HADOOP_HOME/bin/hadoop ustreaming \
    -D mapred.job.name=$JOB_NAME \
    -D mapred.max.split.size=$split_size \
    -D mapred.combine.input.format.local.only=false \
    -D mapred.map.tasks.speculative.execution=false \
    -D mapred.job.map.capacity=1000 \
	-D mapred.job.priority=HIGH \
    -D mapred.reduce.tasks=101 \
    -D mapred.min.split.size=4294967296 \
    -input $INPUT_PATH \
    -output $output \
    -mapper "Python/Jumbo/bin/python.sh pc_mergelog_stream.py run_map $sample_id $src_id ./target_key" \
    -reducer "cat" \
    -inputformat org.apache.hadoop.mapred.SequenceFileAsBinaryInputFormat \
    -mapinstream binary \
    -file "./pc_mergelog_stream.py" \
    -file "./target_key" \
    -cacheArchive $recommend_path/libs/Jumbo.tar.gz"#Python" \
    -cacheArchive $recommend_path/libs/rec_pypb_serde.tar.gz"#."
