#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-

################################################################################
#
# Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
This module provides a baidu hadoop bistreaming framework for Python.

Version: 1.0.0.2
Date: 2014.07.17
By: yangxiaoliang01@baidu.com
Brief: IO read memory performance optimization

Version: 1.0.0.1
Date: 2014.07.01

Rewrite by: yangxiaoliang01@baidu.com

New Feature: new style reduce() interface

Fix bug: read data from pipe incompletely, leading to MapTask Broken Pipe
Modified accroding to baidu Python code-style @2014

"""

import sys
import struct


def log_warn(message):
    """log warning
    """
    print >> sys.stderr, message


def incr_counter(group, counter, amount):
    """User-Defined Streaming Counters
    The line must have the following format:
        reporter:counter:group,counter,amount
    """
    sys.stderr.write("reporter:counter:{group},{counter},{amount}\n".format(
        group=group, counter=counter, amount=amount))


class StreamReadBuffer(object):
    """Hold those buffs read from stdin
    """
    def __init__(self):
        self.__buff_list = []
        self.__start_byte_index = 0
        self.__total_buff_len = 0

    def length(self):
        """length of all the data blocks
        """
        return self.__total_buff_len

    def append_block(self, buff):
        """append one block
        """
        self.__buff_list.append(buff)
        self.__total_buff_len += len(buff)

    def del_from_head(self, length):
        """remove {length} bytes from head
        """
        need_del_len = length
        del_block_num = 0

        for i in range(0, len(self.__buff_list)):
            if i == 0:
                block_len = len(self.__buff_list[i]) - self.__start_byte_index
            else:
                block_len = len(self.__buff_list[i])
            if need_del_len >= block_len:
                need_del_len -= block_len
                self.__total_buff_len -= block_len
                del_block_num += 1
        del self.__buff_list[0: del_block_num]
        if del_block_num == 0:
            self.__start_byte_index += need_del_len
        else:
            self.__start_byte_index = need_del_len
        self.__total_buff_len -= need_del_len

    def slice(self, start, end):
        """ [start, end)
        Args:
            0 <= start <= end <= buffer.length
        """
        need_len = end - start

        start_block_num = 0
        in_block_offset = 0
        block_list = []
        # 1. searh for real start block number and offset
        for i in range(0, len(self.__buff_list)):
            if i == 0:
                block_len = len(self.__buff_list[0]) - self.__start_byte_index
            else:
                block_len = len(self.__buff_list[i])

            if start < block_len:
                start_block_num = i 
                if i == 0:
                    in_block_offset = self.__start_byte_index + start
                else:
                    in_block_offset = start
                break
            else:
                start -= block_len
                continue

        # 2. get blocks in the slice
        for i in range(start_block_num, len(self.__buff_list)):
            if i == start_block_num:
                block_len = len(self.__buff_list[i]) - in_block_offset
                if need_len >= block_len:
                    if in_block_offset == 0:
                        block_list.append(self.__buff_list[i])
                    else:
                        block_list.append(self.__buff_list[i][in_block_offset:])
                    need_len -= (len(self.__buff_list[i]) - in_block_offset)
                else:
                    block_list.append(self.__buff_list[i][in_block_offset:
                        in_block_offset + need_len])
                    need_len = 0
                    break
            else:
                block_len = len(self.__buff_list[i])
                if need_len >= block_len:
                    block_list.append(self.__buff_list[i])
                    need_len -= block_len
                else:
                    block_list.append(self.__buff_list[i][0: need_len])
                    need_len = 0
                    break
        return "".join(block_list)


class BistreamingPipeInput(object):
    """Hadoop bistreaming input
    Hadoop bistreaming binary input data format is as follows:
    [keylen:4 bytes][key:keylen bytes][valuelen:4 bytes][value:valuelen bytes]
    """
    def __init__(self, instream=None):
        """
        Args:
            instream: file object, default sys.stdin
        """
        self._key = None
        self._value = None
        self.__read_buffer = StreamReadBuffer()
        self.__eof = False
        self.__instream = instream
        if instream is None:
            self.__instream = sys.stdin

    def __read_block(self, size):
        """Try fetch one block from stdin
        
        Loop reading from stdin, until we have got {size} byte data, or EOF

        Args:
            size: data size wanted

        Returns:
            A str contains at most {size} bytes data,
            self.__eof will be set to True if EOF encounterd

        """
        read_need = size
        read_count = 0
        buff_list = []
        while read_need > 0:
            #buff = sys.stdin.read(read_need)
            buff = self.__instream.read(read_need)
            read_count += len(buff)
            read_need = size - read_count
            if "" == buff:
                self.__eof = True
                break
            buff_list.append(buff)
        return ''.join(buff_list)

    def next_record(self):
        """Fecth one k-v record from self.__buff or stremaing stdin
        Done 2014.07.17: this implementation may needs memory performance 
        optimization

        Args:

        Returns:
            return True if fetch OK, False else
        """
        BLKSZ = 2048000

        # no more data
        if self.__read_buffer.length() == 0 and self.__eof:
            return False

        # read record key
        if self.__read_buffer.length() < 4:
            self.__read_buffer.append_block(self.__read_block(BLKSZ))
        if self.__read_buffer.length() < 4:
            log_warn("input data record incomplete")
            return False
        keylen = struct.unpack('<I', self.__read_buffer.slice(0, 4))[0]

        if self.__read_buffer.length() - 4 < keylen:
            self.__read_buffer.append_block(self.__read_block(
                max(keylen - self.__read_buffer.length() + 4, BLKSZ)))
        if self.__read_buffer.length() - 4 < keylen:
            log_warn("record incomplete")
            return False
        self._key = self.__read_buffer.slice(4, 4 + keylen)

        # read record value
        # valuelen starts at 4 + keylen
        # value starts at 8 + keylen
        if self.__read_buffer.length() - 4 - keylen < 4:
            self.__read_buffer.append_block(self.__read_block(BLKSZ))
        if self.__read_buffer.length() - 4 - keylen < 4:
            log_warn("record incomplete")
            return False
        valuelen = struct.unpack('<I',
            self.__read_buffer.slice(4 + keylen, 4 + keylen + 4))[0]

        if self.__read_buffer.length() - 4 - keylen - 4 < valuelen:
            to_read_len = max(
               4 + keylen + 4 + valuelen - self.__read_buffer.length(), BLKSZ)
            self.__read_buffer.append_block(self.__read_block(to_read_len))
        if (self.__read_buffer.length() - 4 - keylen - 4) < valuelen:
            log_warn("record incomplete")
            return False
        self._value = self.__read_buffer.slice(
            4 + keylen + 4, 4 + keylen + 4 + valuelen)

        # strip this record bytes from self.__read_buffer
        self.__read_buffer.del_from_head(4 + keylen + 4 + valuelen)
        #print "key:%d, value:%d" %(keylen, valuelen)
        # check k-v valid again
        if keylen == len(self._key) and valuelen == len(self._value):
            return True

        return False

    def key(self):
        """record key
        """
        return self._key

    def value(self):
        """record value
        """
        return self._value


class Context(object):
    """
    Mapper, Reducer Context
    """
    def __init__(self, outstream=None):
        self.__outstream = outstream
        if outstream is None:
            self.__outstream = sys.stdout

    def emit_to_stream(self, key, value):
        """write a k-v record to bistreaming pipe(stdout)
        Args:
            outstream: file object, default sys.stdout
        """
        keylen = struct.pack('<I', len(key))
        valuelen = struct.pack('<I', len(value))
        self.__outstream.write(keylen + key + valuelen + value)


class BistreamingMapper(object):
    """BistreamingMapper

    Methods will be called as follows:
    on_task_begin()
    for each k-v record
        map(record)
    on_task_end()

    on_task_cancel() would be call when on_task_begin(),map(),on_task_end()
    return -1

    """
    def __init__(self):
        self.context = None  # it will be set by framework

    def on_task_begin(self):
        """Be called before map()
        """
        return 0

    def on_task_end(self):
        """Be called after map()
        """
        return 0

    def on_task_cancel(self):
        """Be called on map() return non-zero
        """
        return 0

    def map(self, input_record):
        """
        input_record: BistreamingPipeInput
        """
        return 0

    def emit(self, key, value):
        """write record to streaming pipe
        """
        self.context.emit_to_stream(key, value)


class ReduceInput(BistreamingPipeInput):
    """Reduce Input
    Usage: see the demo bellow
    """
    def __init__(self, instream=None):
        BistreamingPipeInput.__init__(self, instream)
        self.__look_forward_one_key = None
        self.__look_forward_one_value = None
        self.__has_error = False

    def next_key(self):
        """Walk throuth recoreds to the next key

        Returns:
            True: if OK
            False: if no more or error happened
        """
        # self.itervalues() may look forward one k-v to terminate
        if self.__look_forward_one_key is not None:
            self.__look_forward_one_key = None
            self.__look_forward_one_value = None
            return True

        current_key = self._key
        while self.next_record():
            if self._key != current_key:
                return True

        return False

    def itervalues(self):
        """Return the iterator of values for the current key
        Call it after nex_key() return True, or unexpected things may happend
        """
        if self._key is not None:
            yield self._value
        else:
            return
        current_key = self._key
        while self.next_record():
            if self._key == current_key:
                yield self._value
            else:
                self.__look_forward_one_key = self._key
                self.__kook_forward_one_value = self._value
                break


class BistreamingReducer(object):
    """Base Reducer class
    """
    def __init__(self):
        self.context = None

    def on_task_begin(self):
        """be called before reduce()
        """
        return 0

    def on_task_end(self):
        """be called after reduce()
        """
        return 0

    def on_task_cancel(self):
        """be called on reduce() return non-zero
        """
        return 0

    def reduce(self, key, itervalues):
        """
        Args:
            key: type str, binary bytes stored in str
            itervalues: a generator of values for this key,
                value is binary bytes store in str
                usage:
                    for value in itervalues:
                        do_some_thing(value)

        """
        return 0

    def emit(self, key, value):
        """Write a record to streaming pipe
        """
        self.context.emit_to_stream(key, value)


class BistreamingFramework(object):
    """Mapred framework
    """
    def __init__(self, mapper, reducer, instream=None, outstream=None):
        """
        Args:
            instream: if None, default is sys.stdin
            outstream: if None, default is sys.stdout
        """
        self.map_input = BistreamingPipeInput(instream)
        self.reduce_input = ReduceInput(instream)

        self.mapper = mapper
        if mapper is not None:
            map_context = Context(outstream=sys.stdout)
            self.mapper.context = map_context

        self.reducer = reducer
        if reducer is not None:
            reduce_context = Context(outstream=sys.stdout)
            self.reducer.context = reduce_context

    def run_map(self):
        """ run map
        """
        ret = self.mapper.on_task_begin()
        if 0 != ret:
            log_warn("map on_task_begin error (%d)" % ret)
            self.mapper.on_task_cancel()
            return ret

        while self.map_input.next_record():
            ret = self.mapper.map(self.map_input)
            if 0 != ret:
                log_warn("map error (%d)" % ret)
                self.mapper.on_task_cancel()
                return ret

        ret = self.mapper.on_task_end()
        if 0 != ret:
            log_warn("map on_task_end error (%d)" % ret)
            self.mapper.on_task_cancel()
            return ret

        return 0

    def run_reduce(self):
        """run reduce
        """
        ret = self.reducer.on_task_begin()
        if 0 != ret:
            log_warn("map on_task_begin error (%d)" % ret)
            self.reducer.on_task_cancel()
            return ret

        while self.reduce_input.next_key():
            ret = self.reducer.reduce(
                self.reduce_input.key(), self.reduce_input.itervalues())
            if 0 != ret:
                log_warn("reduce_input has error")
                self.reducer.on_task_cancel()
                return ret

        ret = self.reducer.on_task_end()
        if 0 != ret:
            log_warn("map on_task_begin error (%d)" % ret)
            self.reducer.on_task_cancel()
            return ret

        return 0


class WordCountMapper(BistreamingMapper):
    """ mapper
    """
    def on_task_begin(self):
        log_warn("on_task_begin")
        return 0

    def on_task_end(self):
        log_warn("on_task_end")
        return 0

    def on_task_cancel(self):
        log_warn("on_task_cancel")
        return 0

    def map(self, input_record):
        # key: bytes offset, value: word line
        self.emit(input_record.value(), "1")

        # for test
        #print >> sys.stdout, "{}\t{}".format(input_record.value(), "1")
        return 0


class WordCountReducer(BistreamingReducer):
    """ reducer
    """
    def on_task_begin(self):
        log_warn("on_task_begin")
        return 0

    def on_task_end(self):
        log_warn("on_task_end")
        return 0

    def on_task_cancel(self):
        log_warn("on_task_cancel")
        return 0

    def reduce(self, key, itervalues):
        """Easily to understand :-)
        """
        count = 0
        for value in itervalues:
            count += int(value)
        self.emit(str(count), key)
        return 0


def main():
    """Demo usage
    """
    framework = BistreamingFramework(
        mapper=WordCountMapper(), reducer=WordCountReducer())

    task = sys.argv[1]
    if "wordcount_map" == task:
        return framework.run_map()
    elif "wordcount_reduce" == task:
        return framework.run_reduce()
    else:
        log_warn("task type:%s error" % task)
        return -1

if __name__ == '__main__':
    sys.exit(main())
