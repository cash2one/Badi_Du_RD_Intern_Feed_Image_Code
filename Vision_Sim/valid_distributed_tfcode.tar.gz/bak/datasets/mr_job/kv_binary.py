# -*- coding: UTF-8 -*-

"""
Copyright (c) 2013 Baidu.com, Inc. All Rights Reserved
@brief

"""

import sys
import struct

#keylen, key, vallen, val

def emit_kv(key, value):
  key_len = len(key)
  sys.stdout.write(struct.pack("<I", key_len))
  key_fm = ">%ds" % key_len
  key_byte = struct.pack(key_fm, key)
  sys.stdout.write(key_byte)
  value_len = len(value)
  sys.stdout.write(struct.pack("<I", value_len))
  value_fm = ">%ds" % value_len
  value_byte = struct.pack(value_fm, value)
  sys.stdout.write(value_byte)

# get key, value from sequenceFile
def parse_kv():
  key_len_byte = sys.stdin.read(4)
  if not key_len_byte:
    return (None, None)
  key_len = struct.unpack('<I', key_len_byte)[0]
  key_byte = sys.stdin.read(key_len)
  key_fm = '>%ds' % (key_len)
  key = struct.unpack(key_fm, key_byte)[0]
  val_len_byte = sys.stdin.read(4)
  val_len = struct.unpack('<I', val_len_byte)[0]
  val_byte = sys.stdin.read(val_len)
  val_fm = '>%ds' % (val_len)
  val = struct.unpack(val_fm, val_byte)[0]
  return (key, val)
