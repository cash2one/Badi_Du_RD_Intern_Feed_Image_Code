#!/bin/bash

hadoop=/home/users/zhuoan/tools/hadoop-client/nmg01/hadoop/bin/hadoop

$hadoop fs -rmr recommend/libs/rec_pypb_serde.tar.gz

rm rec_pypb_serde.tar.gz

tar zcvf rec_pypb_serde.tar.gz serde __init__.py log.py kv_binary.py mergelog_parser.py mergelog_processor.py pybistreaming.py

$hadoop fs -put rec_pypb_serde.tar.gz recommend/libs/rec_pypb_serde.tar.gz
