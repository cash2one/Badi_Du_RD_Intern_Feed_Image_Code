# -*- coding: UTF-8 -*-
"""
Copyright (c) 2013 Baidu.com, Inc. All Rights Reserved
@brief

"""

import sys
import pprint
import time
import re
import traceback
import base64
import urllib2
import copy
import simplejson as json

from itertools import groupby
from operator import itemgetter

from kv_binary import emit_kv
from kv_binary import parse_kv

import log
import logging
import pybistreaming
import mergelog_parser
import mergelog_processor
import serde.com.baidu.ps.ubm.libpc_mergelog as pc_mergelog

class MergelogMapper(pybistreaming.BistreamingMapper):
    def __init__(self, sample_id, src_id, target_file=None):
        self._sample_id = sample_id
        self._src_id = src_id
        self._target_file = target_file
        super(pybistreaming.BistreamingMapper, self).__init__()

    def on_task_begin(self):
        print >> sys.stderr, "on_task_begin"
        self.parser = mergelog_parser.MergeLogParser()
        self.parser.init_context(self._sample_id, self._src_id, self._target_file)
        return 0
    
    def on_task_end(self):
        print >> sys.stderr, "on_task_end"
        self.parser.destroy_context()
        return 0
    
    def map(self, input_record):
        key = input_record.key()
        value = input_record.value() 
        # 这里写自己的逻辑
        try:
            pc_mergelog_access = pc_mergelog.UbmMergelogAccess()
            pc_mergelog_access.ParseFromString(value)
            joined_msg = pc_mergelog_access.joined_msg
            
            session = mergelog_parser.MergeLogSession()
            self.parser.parser_session(session, joined_msg) 
            #print display_log.DebugString()
            #print click_log.DebugString()
            # 输入一条K-V
            #self.emit(out_key, out_value)
        except:
            traceback.print_exc()
        return 0

class MergelogReducer(pybistreaming.BistreamingReducer):
    def on_task_begin(self):
        print >> sys.stderr, "on_task_begin"
        return 0
    
    def on_task_end(self):
        print >> sys.stderr, "on_task_end"
        return 0
    
    def reduce(self, key, itervalues):
        for value in itervalues:
            # do something 
            out_key="xxx"
            out_value="xxx"
            self.emit(out_key, out_value)
        return 0

def run_mergelog_reduce():
    last_key = None
    last_disp = 0
    last_click = 0
    for line in sys.stdin:
        parts = line.strip().split('\t')
        if len(parts) != 3:
            continue

        query_uri = parts[0]
        disp_num = int(parts[1])
        click_num = int(parts[2])

        if query_uri != last_key:
            if last_key is not None:
                print "%s\t%d\t%d" % (last_key, last_disp, last_click)
            last_key = None
            last_disp = 0
            last_click = 0

        last_key = query_uri
        last_disp += disp_num
        last_click += click_num

    if last_key is not None:
        print "%s\t%d\t%d" % (last_key, last_disp, last_click)

    return 0

def main():
    sample_id = 0
    src_id = 0
    target_file = None
    task = sys.argv[1]
    if len(sys.argv) > 3:
        sample_id = int(sys.argv[2])
        src_id = int(sys.argv[3])
    
    if len(sys.argv) > 4:
        target_file = sys.argv[4]

    framework = pybistreaming.BistreamingFramework(
            mapper=MergelogMapper(sample_id, src_id, target_file), reducer=None)

    if "run_map" == task:
        return framework.run_map()
    elif "run_reduce" == task:
        return run_mergelog_reduce()
    else:
        log_warn("task type:%s error" % task)
        return -1

if __name__ == '__main__':
    #reload(sys)
    #sys.setdefaultencoding("utf-8")
    sys.exit(main())
    
