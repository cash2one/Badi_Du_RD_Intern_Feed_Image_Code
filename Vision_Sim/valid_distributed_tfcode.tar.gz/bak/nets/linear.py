#!/usr/bin/env python
# -*- coding: utf-8 -*-
########################################################################
# 
# Copyright (c) 2017 Baidu.com, Inc. All Rights Reserved
# 
########################################################################
 
"""
File: nets/linear.py
Author: tuku(tuku@baidu.com)
Date: 2017/04/24 16:07:01
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import six

import tensorflow as tf
from tensorflow.contrib import layers
from tensorflow.contrib.layers.python.layers import feature_column_ops
from tensorflow.python.ops import partitioned_variables

slim = tf.contrib.slim

def linear_arg_scope(weight_decay=0.0):
  """Defines the default linear argument scope.

  """
  with slim.arg_scope(
      [slim.conv2d, slim.fully_connected],
      weights_regularizer=slim.l2_regularizer(weight_decay),
      weights_initializer=tf.truncated_normal_initializer(stddev=0.1),
      activation_fn=tf.nn.relu) as sc:
    return sc

def _one_class_to_two_class_logits(logits):
  return tf.concat((tf.zeros_like(logits), logits), 1)

def linear(features, num_classes=None, is_training=True, 
        num_ps_replicas=0, joint_weights=False):
  
  if not isinstance(features, dict):
    features = {'features': features}
  
  parent_scope = "linear"
  partitioner = partitioned_variables.min_max_variable_partitioner(
      max_partitions=num_ps_replicas,
      min_slice_size=64 << 20)

  with tf.variable_scope(
      parent_scope,
      values=tuple(six.itervalues(features)),
      partitioner=partitioner) as scope:
    if joint_weights:
      layer_fn = layers.joint_weighted_sum_from_feature_columns
    else:
      layer_fn = layers.weighted_sum_from_feature_columns
    
    feature_cols = feature_column_ops.infer_real_valued_columns(features)
    logits, _, _ = layer_fn(
            columns_to_tensors=features,
            feature_columns=feature_cols,
            num_outputs=1,
            weight_collections=[parent_scope],
            scope=scope)
    
  two_class_logits = _one_class_to_two_class_logits(logits)
  #logits = layers.linear(logits, 1, scope="logits")
  logits = tf.squeeze(logits, squeeze_dims=(1,), name="logits")

  #TODO add centered_bias
  #logits = nn.bias_add(logits, centered_bias)

  end_points = {}  
  if num_classes is not None:
    end_points['logistic'] = tf.sigmoid(logits)
    end_points['probability'] = tf.nn.softmax(two_class_logits)
    #end_points['features'] = features['features']
         
  return logits, end_points
